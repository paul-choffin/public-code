---
title: "Articles"
date: 2017-03-02T12:00:00-05:00
---
Articles are paginated with only three posts here for example. You can set the number of entries to show on this page with the "pagination" setting in the config file.
